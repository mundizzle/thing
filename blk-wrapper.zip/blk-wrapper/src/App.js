import { useContext } from "react";
import { BrowserRouter, Switch, Route, Redirect } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "react-query";
import { useLocalStorage } from "react-use";

import { UserContext, UserProvider, initialUser } from "./context/user";

import { NotFound } from "./routes/not_found";
import { Home } from "./routes/home";
import { Login } from "./routes/login";
import { Report } from "./routes/report";

const queryClient = new QueryClient();

function App() {
  const [user, setUser] = useLocalStorage("user", initialUser);
  return (
    <UserProvider value={user}>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <Switch>
            <Route
              path="/login"
              render={(props) => {
                if (user.isAuthenticated) return <Redirect to="/" />;
                return <Login {...props} setUser={setUser} />;
              }}
            />
            <AuthRoute exact path="/" component={Home} />
            <AuthRoute path="/report/:id" component={Report} />
            <Route path="/error" component={NotFound} />
            <Route
              path="*"
              render={(props) => {
                return (
                  <Redirect
                    to={{
                      pathname: "/error",
                      notFound: props.history?.location?.pathname,
                    }}
                  />
                );
              }}
            />
          </Switch>
        </BrowserRouter>
      </QueryClientProvider>
    </UserProvider>
  );
}

const AuthRoute = (props) => {
  const user = useContext(UserContext);
  if (user.isAuthenticated) {
    return <Route {...props} />;
  }
  return <Redirect to="/login" />;
};

export default App;
