const NotFound = () => {
  return <div className="modal-center">Page not found.</div>;
};

export { NotFound };
