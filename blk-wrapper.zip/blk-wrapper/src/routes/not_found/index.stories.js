import React from "react";

import { NotFound } from ".";

export default {
  title: "Pages/Not Found",
  component: NotFound,
};

export const Default = (args) => <NotFound {...args} />;
Default.args = {};
