import { render } from "@testing-library/react";
import { NotFound } from "./";

test("make sure something renders", () => {
  const { container } = render(<NotFound />);
  expect(container).not.toBeEmptyDOMElement();
});
