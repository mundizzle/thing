import { render } from "@testing-library/react";
import { Login } from "./";

test("make sure something renders", () => {
  const { container } = render(<Login />);
  expect(container).not.toBeEmptyDOMElement();
});
