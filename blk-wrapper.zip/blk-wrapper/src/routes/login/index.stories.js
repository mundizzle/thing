import React from "react";

import { Login } from ".";

export default {
  title: "Pages/Login",
  component: Login,
};

export const Default = (args) => <Login {...args} />;
Default.args = {};
