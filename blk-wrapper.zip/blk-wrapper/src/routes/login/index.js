import { useEffect, useContext } from "react";
import { UserContext } from "../../context/user";
import { ReactComponent as Logo } from "../../assets/logo.svg";

import styles from "./styles.module.css";

const Login = ({ setUser }) => {
  const user = useContext(UserContext);
  useEffect(() => {
    document.body.classList.add("login");
    return () => document.body.classList.remove("login");
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    user.isAuthenticated = true;
    setUser(user);
  };

  return (
    <>
      <form className={`modal-center ${styles.form}`} onSubmit={handleSubmit}>
        <h1 aria-label="Onyx">
          <Logo />
        </h1>
        <div>
          <input placeholder="Login with SSO User ID" />
          <button>GO</button>
        </div>
      </form>
    </>
  );
};

export { Login };
