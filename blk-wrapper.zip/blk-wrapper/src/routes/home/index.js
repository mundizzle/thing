import { useReports } from "../../hooks/useReports";

import { DefaultLayout } from "../../components/default_layout";
import { Header } from "../../components/header";
import { Nav } from "../../components/nav";
import { Favorites } from "../../components/favorites";
import { Topics } from "../../components/topics";

import { Loading } from "../../components/loading";
import { Error } from "../../components/error";

import styles from "./styles.module.css";

const Home = () => {
  const { isLoading, error, data: reports } = useReports();

  if (isLoading) return <Loading />;

  if (error) return <Error error={error} />;

  return (
    <DefaultLayout header={<Header />} nav={<Nav reports={reports} isOpen />}>
      <div className="main-inner">
        <input
          className={styles.search}
          type="search"
          placeholder="Search ONYX for specific reports&hellip;"
        />
        <Favorites />
        <Topics />
      </div>
    </DefaultLayout>
  );
};

export { Home };
