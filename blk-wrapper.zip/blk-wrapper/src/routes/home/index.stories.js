import React from "react";
import { rest } from "msw";

import { Home } from "./";

export default {
  title: "Pages/Home",
  component: Home,
};

export const Default = (args) => <Home {...args} />;
Default.args = {};

Default.story = {
  parameters: {
    msw: [
      rest.get("/data/reports.json", (req, res, ctx) => {
        return res(
          ctx.json([
            {
              id: "corporate",
              name: "BlackRock Corporate",
              abbreviation: "BLK",
              url: "/report.html",
            },
            {
              id: "ishares",
              name: "iShares",
              abbreviation: "iS",
              url: "/report.html",
            },
            {
              id: "aladin",
              name: "Aladin",
              abbreviation: "Al",
              url: "/report.html",
            },
            {
              id: "investments",
              name: "BlackRock Investments",
              abbreviation: "Inv",
              url: "/report.html",
            },
          ])
        );
      }),
    ],
  },
};
