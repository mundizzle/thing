import { render } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "react-query";
import { Home } from "./";

const queryClient = new QueryClient();

test("make sure something renders", () => {
  const { container } = render(
    <QueryClientProvider client={queryClient}>
      <Home />
    </QueryClientProvider>
  );
  expect(container).not.toBeEmptyDOMElement();
});
