import React from "react";
import { MemoryRouter, Route } from "react-router-dom";
import { rest } from "msw";

import { Report } from "./";

export default {
  title: "Pages/Report",
  component: Report,
};

export const Default = (args) => {
  return (
    <MemoryRouter initialEntries={["/report/corporate"]}>
      <Route
        component={(routerProps) => <Report {...args} {...routerProps} />}
        path="/report/:id"
      />
    </MemoryRouter>
  );
};
Default.args = {};

Default.story = {
  parameters: {
    msw: [
      rest.get("/data/reports.json", (req, res, ctx) => {
        return res(
          ctx.json([
            {
              id: "corporate",
              name: "BlackRock Corporate",
              abbreviation: "BLK",
              url: "/report.html",
            },
            {
              id: "ishares",
              name: "iShares",
              abbreviation: "iS",
              url: "/report.html",
            },
            {
              id: "aladin",
              name: "Aladin",
              abbreviation: "Al",
              url: "/report.html",
            },
            {
              id: "investments",
              name: "BlackRock Investments",
              abbreviation: "Inv",
              url: "/report.html",
            },
          ])
        );
      }),
    ],
  },
};
