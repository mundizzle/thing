import { render } from "@testing-library/react";
import { MemoryRouter, Route } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "react-query";
import { Report } from "./";

const queryClient = new QueryClient();

test("make sure something renders", () => {
  const { container } = render(
    <QueryClientProvider client={queryClient}>
      <MemoryRouter initialEntries={["/report/corporate"]}>
        <Route
          component={(routerProps) => <Report {...routerProps} />}
          path="/report/:id"
        />
      </MemoryRouter>
    </QueryClientProvider>
  );
  expect(container).not.toBeEmptyDOMElement();
});
