import { useParams } from "react-router-dom";
import { useReports } from "../../hooks/useReports";

import { DefaultLayout } from "../../components/default_layout";
import { Header } from "../../components/header";
import { Nav } from "../../components/nav";

import { Loading } from "../../components/loading";
import { Error } from "../../components/error";

const Report = () => {
  let { id } = useParams();
  const { isLoading, error, data: reports } = useReports();

  if (isLoading) return <Loading />;

  if (error) return <Error error={error} />;

  const report = reports.find((report) => report.id === id);

  if (!report)
    return <Error error={{ message: `Report ID "${id}" not found.` }} />;

  const { name, url } = report;

  return (
    <DefaultLayout
      header={<Header />}
      nav={<Nav reports={reports} currentReportId={id} />}
    >
      <div className="main-inner">
        <iframe className="report-iframe" src={url} title={name}></iframe>
      </div>
    </DefaultLayout>
  );
};

export { Report };
