import { rest } from "msw";
import { setupServer } from "msw/node";
import { renderHook, act } from "@testing-library/react-hooks";
import { useReports } from "./useReports";
import { QueryClient, QueryClientProvider } from "react-query";

const data = [
  {
    id: "investments",
    name: "BlackRock Investments",
    abbreviation: "Inv",
    url: "/report.html",
  },
];

const server = setupServer(
  rest.get("/data/reports.json", (req, res, ctx) => {
    return res(ctx.json(data));
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

const queryClient = new QueryClient();
const wrapper = ({ children }) => (
  <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
);

const { result, waitFor } = renderHook(() => useReports(), { wrapper });

it("should return data when API responds 200", async () => {
  await waitFor(() => result.current.isSuccess);

  expect(result.current.isSuccess).toEqual(true);
  expect(result.current.data).toEqual(data);
});
