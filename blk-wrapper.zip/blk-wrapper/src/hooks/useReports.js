import { useQuery } from "react-query";
import { getReports } from "../api/getReports";

const useReports = () => useQuery("reports", getReports);

export { useReports };
