const Error = ({ error }) => {
  return (
    <div className="modal-center">
      Error
      <p>{error?.message}</p>
    </div>
  );
};

export { Error };
