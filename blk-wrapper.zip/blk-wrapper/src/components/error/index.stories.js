import React from "react";

import { Error } from "./";

export default {
  title: "Components/Error",
  component: Error,
};

export const Default = (args) => <Error {...args} />;
Default.args = {
  error: {
    message: "Oops, something went wrong :(",
  },
};
