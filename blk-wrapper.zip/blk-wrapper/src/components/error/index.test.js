import { render } from "@testing-library/react";
import { Error } from "./";

test("make sure something renders", () => {
  const { container } = render(<Error />);
  expect(container).not.toBeEmptyDOMElement();
});
