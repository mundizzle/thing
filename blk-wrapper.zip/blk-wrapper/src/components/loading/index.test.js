import { render } from "@testing-library/react";
import { Loading } from "./";

test("make sure something renders", () => {
  const { container } = render(<Loading />);
  expect(container).not.toBeEmptyDOMElement();
});
