const Loading = () => {
  return <div className="modal-center">Loading...</div>;
};

export { Loading };
