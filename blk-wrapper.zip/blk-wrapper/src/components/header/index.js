import { Link } from "react-router-dom";
import { ReactComponent as Logo } from "../../assets/logo.svg";
import styles from "./styles.module.css";

import { ReactComponent as Alert } from "../../assets/alert.svg";
import { ReactComponent as Settings } from "../../assets/settings.svg";
import { ReactComponent as Help } from "../../assets/help.svg";
import user from "../../assets/user.png";

const Header = () => {
  return (
    <header className={styles.header}>
      <Link to="/">
        <Logo className={styles.logo} aria-label="Onyx" />
      </Link>
      <ul role="menubar" aria-label="functions" className={styles.util}>
        <li role="menuitem" aria-haspopup="true">
          <button className="icon-button" aria-label="Alerts">
            <Alert focusable="false" />
          </button>
        </li>
        <li role="menuitem" aria-haspopup="true">
          <button className="icon-button" aria-label="Settings">
            <Settings focusable="false" />
          </button>
        </li>
        <li role="menuitem" aria-haspopup="true">
          <button className="icon-button" aria-label="Help">
            <Help focusable="false" />
          </button>
        </li>
        <li role="menuitem" aria-haspopup="true">
          <button className="icon-button" aria-label="Profile">
            <img src={user} focusable="false" alt="User" />
          </button>
        </li>
      </ul>
    </header>
  );
};

export { Header };
