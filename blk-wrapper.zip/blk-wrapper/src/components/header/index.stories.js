import React from "react";

import { Header } from "./";

export default {
  title: "Components/Header",
  component: Header,
};

export const Default = (args) => <Header {...args} />;
Default.args = {};
