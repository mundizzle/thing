import React from "react";

import { Favorites } from "./";

export default {
  title: "Components/Favorites",
  component: Favorites,
};

export const Default = (args) => <Favorites {...args} />;
Default.args = {};
