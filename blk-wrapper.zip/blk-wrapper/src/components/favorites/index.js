import styles from "./styles.module.css";

const Favorites = () => {
  return (
    <section>
      <h2>Favorites</h2>
      <ul className={styles.favorites}>
        <li></li>
        <li></li>
      </ul>
    </section>
  );
};

export { Favorites };
