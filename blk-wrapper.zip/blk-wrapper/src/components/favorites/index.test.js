import { render } from "@testing-library/react";
import { Favorites } from "./";

test("make sure something renders", () => {
  const { container } = render(<Favorites />);
  expect(container).not.toBeEmptyDOMElement();
});
