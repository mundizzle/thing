import { render } from "@testing-library/react";
import { Topics } from "./";

test("make sure something renders", () => {
  const { container } = render(<Topics />);
  expect(container).not.toBeEmptyDOMElement();
});
