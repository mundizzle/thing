import styles from "./styles.module.css";
import { ReactComponent as Triangle } from "../../assets/triangle.svg";

const Topics = () => {
  return (
    <section>
      <h2>Topics</h2>
      <div className={styles.carousel}>
        <button className={`${styles.previous} icon-button`}>
          <Triangle />
        </button>
        <ul className={styles.topics}>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
        <button className={`${styles.next} icon-button`}>
          <Triangle />
        </button>
      </div>
      <div className={styles.carousel}>
        <button className={`${styles.previous} icon-button`}>
          <Triangle />
        </button>
        <ul className={styles.topics}>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
        <button className={`${styles.next} icon-button`}>
          <Triangle />
        </button>
      </div>
    </section>
  );
};

export { Topics };
