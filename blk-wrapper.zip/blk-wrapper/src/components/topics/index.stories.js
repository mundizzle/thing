import React from "react";

import { Topics } from "./";

export default {
  title: "Components/Topics",
  component: Topics,
};

export const Default = (args) => <Topics {...args} />;
Default.args = {};
