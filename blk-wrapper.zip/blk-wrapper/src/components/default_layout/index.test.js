import { render } from "@testing-library/react";
import { DefaultLayout } from "./";

test("make sure something renders", () => {
  const { container } = render(<DefaultLayout />);
  expect(container).not.toBeEmptyDOMElement();
});
