import styles from "./styles.module.css";

const DefaultLayout = ({ header, nav, children, footer }) => {
  return (
    <div className={styles.layout}>
      <header>{header}</header>
      <nav>{nav}</nav>
      <main>{children}</main>
      <footer>{footer}</footer>
    </div>
  );
};

export { DefaultLayout };
