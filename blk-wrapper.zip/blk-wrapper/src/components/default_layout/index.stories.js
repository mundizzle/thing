import React from "react";

import { DefaultLayout } from "./";
import styles from "./styles.module.css";

export default {
  title: "Layouts/Default",
  component: DefaultLayout,
  decorators: [(Story) => <div className={styles.sb}>{Story()}</div>],
};

export const Default = (args) => <DefaultLayout {...args} />;
Default.args = {
  header: "Header content goes here...",
  nav: "Navigation content goes here...",
  children: "Main content goes here...",
  footer: "Footer content goes here...",
};
