import { Link } from "react-router-dom";

const Item = ({ id, isCurrent, open, abbreviation, name }) => {
  return (
    <li data-is-current={isCurrent}>
      <Link to={`/report/${id}`}>
        {open ? name : <abbr title={name}>{abbreviation}</abbr>}
      </Link>
    </li>
  );
};

export { Item };
