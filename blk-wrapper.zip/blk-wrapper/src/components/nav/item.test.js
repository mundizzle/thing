import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { Item } from "./item";

test("make sure something renders", () => {
  const { container } = render(
    <MemoryRouter>
      <Item />
    </MemoryRouter>
  );
  expect(container).not.toBeEmptyDOMElement();
});
