import React from "react";

import styles from "./styles.module.css";
import { Item } from "./item";

export default {
  title: "Components/Nav Item",
  component: Item,
};

export const Default = (args) => (
  <div data-is-open={args.open}>
    <ul className={styles.reports}>
      <Item {...args} />
    </ul>
  </div>
);
Default.args = {
  isCurrent: true,
  open: true,
  id: "corporate",
  name: "BlackRock Corporate",
  abbreviation: "BLK",
  url: "/report.html",
};
