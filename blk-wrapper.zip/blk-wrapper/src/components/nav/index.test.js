import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

import { Nav } from "./";

test("make sure something renders", () => {
  const { container } = render(
    <MemoryRouter>
      <Nav />
    </MemoryRouter>
  );
  expect(container).not.toBeEmptyDOMElement();
});
