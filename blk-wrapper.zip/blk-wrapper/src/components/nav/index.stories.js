import React from "react";

import { Nav } from "./";

export default {
  title: "Components/Nav",
  component: Nav,
};

export const Default = (args) => <Nav {...args} />;
Default.args = {
  isOpen: true,
  currentReportId: "corporate",
  reports: [
    {
      id: "corporate",
      name: "BlackRock Corporate",
      abbreviation: "BLK",
      url: "/report.html",
    },
    {
      id: "ishares",
      name: "iShares",
      abbreviation: "iS",
      url: "/report.html",
    },
  ],
};
