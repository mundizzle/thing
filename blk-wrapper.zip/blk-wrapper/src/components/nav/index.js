import { useState } from "react";
import { ReactComponent as Toggle } from "../../assets/toggle.svg";
import { Item } from "./item";
import styles from "./styles.module.css";

const Nav = ({ reports, isOpen, currentReportId }) => {
  const [open, setOpen] = useState(isOpen);
  return (
    <div data-is-open={open}>
      <button
        className={`${styles.toggle} icon-button`}
        aria-label="Reports Menu"
        onClick={() => {
          setOpen(open ? false : true);
        }}
      >
        <Toggle focusable="false" />
      </button>
      <ul className={styles.reports}>
        {reports.map((report, i) => {
          report.isCurrent = report.id === currentReportId;
          report.open = open;
          return <Item key={i} {...report} />;
        })}
      </ul>
    </div>
  );
};

export { Nav };
