import React from "react";
import { render, screen } from "@testing-library/react";
import { UserContext } from "./user";

test("UserConsumer shows default value", () => {
  render(
    <UserContext.Consumer>{(user) => <div>hello</div>}</UserContext.Consumer>
  );
  expect(screen.getByText(/^hello/)).toHaveTextContent("hello");
});
