import { createContext } from "react";

const initialUser = { isAuthenticated: false };

const UserContext = createContext(initialUser);

function UserProvider({ children, value }) {
  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export { UserContext, UserProvider, initialUser };
