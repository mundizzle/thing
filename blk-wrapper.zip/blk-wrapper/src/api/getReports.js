const getReports = async () => {
  return await fetch("/data/reports.json").then((response) => response.json());
};

export { getReports };
