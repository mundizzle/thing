import { MemoryRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "react-query";
import { addDecorator } from "@storybook/react";
import { jsxDecorator } from "storybook-addon-jsx";
import { initializeWorker, mswDecorator } from "msw-storybook-addon";
import "../src/index.css";
import theme from "./theme";

const tokenContext = require.context(
  "!!raw-loader!../src",
  true,
  /.\.(css|less|scss|svg)$/
);

const queryClient = new QueryClient();

initializeWorker();

addDecorator(mswDecorator);
addDecorator(jsxDecorator);

const tokenFiles = tokenContext.keys().map(function (filename) {
  return { filename: filename, content: tokenContext(filename).default };
});

export const parameters = {
  controls: {
    docs: {
      viewMode: "docs",
      theme: theme,
    },
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  designToken: {
    files: tokenFiles,
  },
};

export const decorators = [
  (Story) => (
    <QueryClientProvider client={queryClient}>
      <MemoryRouter>
        <Story />
      </MemoryRouter>
    </QueryClientProvider>
  ),
];
