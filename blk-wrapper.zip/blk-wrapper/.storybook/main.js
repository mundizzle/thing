module.exports = {
  stories: ["../src/**/*.stories.mdx", "../src/**/*.stories.@(js|jsx|ts|tsx)"],
  addons: [
    "@storybook/addon-links",
    {
      name: "@storybook/addon-essentials",
      options: {
        actions: false,
        backgrounds: false,
      },
    },
    "@storybook/preset-create-react-app",
    "@storybook/addon-a11y",
    "@storybook/addon-design-assets",
    "@whitespace/storybook-addon-html",
    "storybook-addon-jsx",
    "storybook-addon-pseudo-states",
    "storybook-design-token",
  ],
};
